package com.company;

import java.io.Serializable;

public class WrongPasswordException extends Exception {
}

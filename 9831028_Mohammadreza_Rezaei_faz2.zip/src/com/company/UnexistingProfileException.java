package com.company;

import java.io.Serializable;

public class UnexistingProfileException extends Exception{
}
